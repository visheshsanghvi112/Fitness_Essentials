
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>FitnessEssentials.vishesh</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Topbar Start -->

    
    <div class="container-fluid">
        <div class="row bg-secondary py-2 px-xl-5">
            <div class="col-lg-6 d-none d-lg-block">
                <div class="d-inline-flex align-items-center">
                    <a class="text-dark" href="contact.html">FAQs</a>
                    <span class="text-muted px-2">|</span>
                    <a class="text-dark" href="contact.html">Help</a>
                    <span class="text-muted px-2">|</span>
                    <a class="text-dark" href="contact.html">Support</a>
                </div>
            </div>

            <?php 
            @include 'config.php';
  session_start();
    if($_SESSION['user_name']==true){ 
        echo $_SESSION["user_name"];
        echo '<a href="logout.php"><span>Logout</span></a></li>';
        }
    elseif($_SESSION['user_name']==false) 
        echo '<a href="login_form.php" class="nav-item nav-link">Login</a>
        <a href="register_form.php" class="nav-item nav-link">Register</a>';
    ?>
            
            <div class="col-lg-6 text-center text-lg-right">
                <div class="d-inline-flex align-items-center">
                    <a class="text-dark px-2" href="https://www.facebook.com/vishesh.sanghvi.71/">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a class="text-dark px-2" href="https://twitter.com/muscleblaze?lang=en">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a class="text-dark px-2" href="https://www.linkedin.com/in/vishesh-sanghvi-96b16a237">
                        <i class="fab fa-linkedin-in"></i>
                    </a>
                    <a class="text-dark px-2" href="https://instagram.com/visheshsanghvi__?igshid=YmMyMTA2M2Y=">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a class="text-dark pl-2" href="https://www.youtube.com/watch?v=rzubNgrEhtI">
                        <i class="fab fa-youtube"></i>
                    </a>
                </div>
            </div>
        </div>
        <div class="row align-items-center py-3 px-xl-5">
            <div class="col-lg-3 d-none d-lg-block">
                <a href="" class="text-decoration-none">
                    <h1 class="m-0 display-5 font-weight-semi-bold"><span class="text-primary font-weight-bold border px-3 mr-1">GYM</span>ESSENTIALS</h1>
                </a>
            </div>
            <div class="row-col-lg-6 col-6 text-left">
                <form action="">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search for products">
                        <div class="input-group-append">
                            <span class="input-group-text bg-transparent text-primary">
                                <i class="fa fa-search"></i>
                            </span>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-lg-3 col-6 text-right">
                <a href="/Users/vishesh/Desktop/bootstrap-shop-template/ wishlist.html" class="btn border">
                    <i class="fas fa-heart text-primary"></i>
                    <span class="badge">0</span>
                </a>
                <a href="cart.html" class="btn border">
                    <i class="fas fa-shopping-cart text-primary"></i>
                    <span class="badge">0</span>
                </a>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->

    <div class="container-fluid mb-5">
        <div class="row border-top px-xl-5">
            <!-- <div class="col-lg-3 d-none d-lg-block">
                <a class="btn shadow-none d-flex align-items-center justify-content-between bg-primary text-white w-100" data-toggle="collapse" href="#navbar-vertical" style="height: 65px; margin-top: -1px; padding: 0 30px;">
                    <h6 class="m-0">Categories</h6>
                    <i class="fa fa-angle-down text-dark"></i>
                </a>
                <nav class="collapse show navbar navbar-vertical navbar-light align-items-start p-0 border border-top-0 border-bottom-0" id="navbar-vertical">
                    <div class="navbar-nav w-100 overflow-hidden" style="height: 410px">
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link" data-toggle="dropdown">BRANDS<i class="fa fa-angle-down float-right mt-1"></i></a>
                            <div class="dropdown-menu position-absolute bg-secondary border-0 rounded-0 w-100 m-0">
                                <li id="menu-item-2079426" class="menu-item menu-item-type-custom menu-item-object-custom  menu-item-2079426"><a href="https://nutrabay.com/nutrabay"> Nutrabay</a></li>
                                <li id="menu-item-15768" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-15768"><a href="https://nutrabay.com/brand/optimum-nutrition-on/"> Optimum Nutrition</a></li>
                                <li id="menu-item-35031" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-35031"><a href="https://nutrabay.com/brand/dymatize/"> Dymatize</a></li>
                                <li id="menu-item-29214" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-29214"><a href="https://nutrabay.com/brand/ultimate-nutrition/"> Ultimate Nutrition</a></li>
                                <li id="menu-item-666083" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-666083"><a href="https://nutrabay.com/brand/myfitness/"> MyFitness</a></li>
                                <li id="menu-item-27263" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-27263"><a href="https://nutrabay.com/brand/muscletech/"> MuscleTech</a></li>
                                <li id="menu-item-1032789" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-1032789"><a href="https://nutrabay.com/brand/my-protein/">MyProtein</a></li>
                                <li id="menu-item-27282" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-27282"><a href="https://nutrabay.com/brand/scivation/">Scivation Xtend</a></li>
                                <li id="menu-item-6475560" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-6475560"><a href="https://nutrabay.com/brand/big-muscles/">Bigmuscles Nutrition</a></li>
                                <li id="menu-item-15770" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-15770"><a href="https://nutrabay.com/brand/bsn/">BSN</a></li>
                                <li id="menu-item-38149" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-38149"><a href="https://nutrabay.com/brand/gnc/">GNC</a></li>
                                <li id="menu-item-232042" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-232042"><a href="https://nutrabay.com/brand/isopure-natures-best/">Isopure</a></li>
                                <li id="menu-item-283456" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-283456"><a href="https://nutrabay.com/brand/one-science-nutrition/">One Science Nutrition</a></li>
                                <li id="menu-item-6736034" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-6736034"><a href="https://nutrabay.com/brand/labrada/">Labrada</a></li>
                                <li id="menu-item-7113591" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-7113591"><a href="https://nutrabay.com/brand/doctors-choice/">Doctor&#8217;s Choice</a></li>
                                <li id="menu-item-6736035" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-6736035"><a href="https://nutrabay.com/brand/ritebite/">RiteBite</a></li>
                                <li id="menu-item-6958240" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-6958240"><a href="https://nutrabay.com/brand/absn/">ABSN</a></li>
                                <li id="menu-item-5820166" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-5820166"><a href="https://nutrabay.com/brand/absolute-nutrition/">Absolute Nutrition</a></li>
                                <li id="menu-item-7077467" class="label-new menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-7077467"><a href="https://nutrabay.com/brand/adreno-nutraceuticals/">Adreno Nutraceuticals</a></li>
                                <li id="menu-item-6173028" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-6173028"><a href="https://nutrabay.com/brand/ans/">ANS Performance</a></li>
                                <li id="menu-item-7077502" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-7077502"><a href="https://nutrabay.com/brand/ap-sports/">AP Sports</a></li>
                                <li id="menu-item-6927689" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-6927689"><a href="https://nutrabay.com/brand/asitis/">AS-IT-IS</a></li>
                                <li id="menu-item-5013071" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-5013071"><a href="https://nutrabay.com/brand/avvatar-sports-nutrition/">Avvatar Sports Nutrition</a></li>
                                <li id="menu-item-120342" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-120342"><a href="https://nutrabay.com/brand/big-muscles/">Bigmuscles Nutrition</a></li>
                                <li id="menu-item-5013066" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-5013066"><a href="https://nutrabay.com/brand/billion-cheers/">Billion Cheers</a></li>
                                <li id="menu-item-250047" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-250047"><a href="https://nutrabay.com/brand/biofit/">Biofit</a></li>
                                <li id="menu-item-6876289" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-6876289"><a href="https://nutrabay.com/brand/blackmores/">Blackmores</a></li>
                                <li id="menu-item-6764721" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-6764721"><a href="https://nutrabay.com/brand/bold-care/">Bold Care</a></li>
                                <li id="menu-item-6660405" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-6660405"><a href="https://nutrabay.com/brand/boldfit/">Boldfit</a></li>
                                <li id="menu-item-6992103" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-6992103"><a href="https://nutrabay.com/brand/bolt/">Bolt</a></li>
                                <li id="menu-item-6708525" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-6708525"><a href="https://nutrabay.com/brand/bpi-sports/">BPI Sports</a></li>
                                <li id="menu-item-6301408" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-6301408"><a href="https://nutrabay.com/brand/bsn/">BSN</a></li>
                                <li id="menu-item-6857400" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-6857400"><a href="https://nutrabay.com/brand/calibar/">Calibar</a></li>
                                <li id="menu-item-6489601" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-6489601"><a href="https://nutrabay.com/brand/carbamide-forte/">Carbamide Forte</a></li>
                                <li id="menu-item-27547" class="menu-item menu-item-type-taxonomy menu-item-object-pwb-brand  menu-item-27547"><a href="https://nutrabay.com/brand/cellucor/">Cellucor</a></li>
                            </div>
                        </div>
                        <a href="" class="nav-item nav-link">WHEY PROTEIN</a>
                        <a href="" class="nav-item nav-link">MASS GAINER </a>
                        <a href="" class="nav-item nav-link">BCAA</a>
                        <a href="" class="nav-item nav-link">CREATINE </a>
                        <a href="" class="nav-item nav-link">PLANT PROTEIN</a>
                        <a href="" class="nav-item nav-link">WEIGHTS</a>
                        <a href="" class="nav-item nav-link">HEALTH AND NUTRITION</a>
                        <a href="" class="nav-item nav-link">SHAKERS</a>
                        <a href="" class="nav-item nav-link">GYM BAG</a>
                    </div>
                </nav>
            </div> -->
            <div class="col-lg-12">
                <nav class="navbar navbar-expand-lg bg-light navbar-light py-3 py-lg-0 px-0">
                    <a href="" class="text-decoration-none d-block d-lg-none">
                        <h1 class="m-0 display-5 font-weight-semi-bold"><span class="text-primary font-weight-bold border px-3 mr-1">GYM</span>ESSENTIALS</h1>
                    </a>
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto py-0">
                            <a href="index.html" class="nav-item nav-link active">Home</a>
                            <a href="shop.html" class="nav-item nav-link">Shop</a>
                            <!-- <a href="detail.html" class="nav-item nav-link">Detail</a> -->
                            <div class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Pages</a>
                                <div class="dropdown-menu rounded-0 m-0">
                                    <a href="cart.html" class="dropdown-item">Shopping Cart</a>
                                    <a href="checkout.html" class="dropdown-item">Checkout</a>
                                </div>
                            </div>
                            <a href="contact.html" class="nav-item nav-link">Contact</a>
                        </div>
                        <div class="navbar-nav ml-auto py-0">
                        <?php 
            @include 'config.php';
  session_start();
    if($_SESSION['user_name']==true){ 
        echo $_SESSION["user_name"];
        echo '<a href="logout.php"><span>Logout</span></a></li>';
        }
    elseif($_SESSION['user_name']==false) 
        echo '<a href="login_form.php" class="nav-item nav-link">Login</a>
        <a href="register_form.php" class="nav-item nav-link">Register</a>';
    ?>
                        </div>
                    </div>
                </nav>
                <div id="header-carousel" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active" style="height: 700px;">
                            <img class="img-fluid" src="img/pexels-leon-ardho-1552242.jpg" alt="Image">
                            <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                                <div class="p-3" style="max-width: 1100px;">
                                    <h4 class="text-light text-uppercase font-weight-medium mb-3">10% Off Your First Order</h4>
                                    <h3 class="display-4 text-white font-weight-semi-bold mb-4">NO PAIN NO GAIN</h3>
                                    <a href="shop.html" class="btn btn-light py-2 px-3">Shop Now</a>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item" style="height: 700px;">
                            <img class="img-fluid" src="img/carousel-2.jpg" alt="Image">
                            <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                                <div class="p-3" style="max-width: 1100px;">
                                    <h4 class="text-light text-uppercase font-weight-medium mb-3">10% Off Your First Order</h4>
                                    <h3 class="display-4 text-white font-weight-semi-bold mb-4">Reasonable Price</h3>
                                    <a href="shop.html" class="btn btn-light py-2 px-3">Shop Now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#header-carousel" data-slide="prev">
                        <div class="btn btn-dark" style="width: 45px; height: 45px;">
                            <span class="carousel-control-prev-icon mb-n2"></span>
                        </div>
                    </a>
                    <a class="carousel-control-next" href="#header-carousel" data-slide="next">
                        <div class="btn btn-dark" style="width: 45px; height: 45px;">
                            <span class="carousel-control-next-icon mb-n2"></span>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- Navbar End -->


    <!-- Featured Start -->
    <div class="container-fluid pt-5">
        <div class="row px-xl-5 pb-3">
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="d-flex align-items-center border mb-4" style="padding: 30px;">
                    <h1 class="fa fa-check text-primary m-0 mr-3"></h1>
                    <h5 class="font-weight-semi-bold m-0">Quality Product</h5>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="d-flex align-items-center border mb-4" style="padding: 30px;">
                    <h1 class="fa fa-shipping-fast text-primary m-0 mr-2"></h1>
                    <h5 class="font-weight-semi-bold m-0">Free Shipping</h5>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="d-flex align-items-center border mb-4" style="padding: 30px;">
                    <h1 class="fas fa-exchange-alt text-primary m-0 mr-3"></h1>
                    <h5 class="font-weight-semi-bold m-0">14-Day Return</h5>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="d-flex align-items-center border mb-4" style="padding: 30px;">
                    <h1 class="fa fa-phone-volume text-primary m-0 mr-3"></h1>
                    <h5 class="font-weight-semi-bold m-0">24/7 Support</h5>
                </div>
            </div>
        </div>
    </div>
    <!-- Featured End -->


    <!-- Categories Start -->
    <div class="container-fluid pt-5">
        <div class="row px-xl-5 pb-3">
            <div class="col-lg-4 col-md-6 pb-1">
                <div class="cat-item d-flex flex-column border mb-4" style="padding: 30px;">
                    <p class="text-right">5</p>
                    <a href="shop.html" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="img/MASSGAINER.webp" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">MASS GAINER </h5>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 pb-1">
                <div class="cat-item d-flex flex-column border mb-4" style="padding: 30px;">
                    <p class="text-right">15</p>
                    <a href="shop.html" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="img/ONWHEY.webp" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">PROTEIN</h5>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 pb-1">
                <div class="cat-item d-flex flex-column border mb-4" style="padding: 30px;">
                    <p class="text-right">15 Products</p>
                    <a href="shop.html" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="img/victor-freitas-JbI04nYfaJk-unsplash.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">WEIGHTS</h5>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 pb-1">
                <div class="cat-item d-flex flex-column border mb-4" style="padding: 30px;">
                    <p class="text-right">15 Products</p>
                    <a href="shop.html" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="img/SHAKER.webp" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Accerssories</h5>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 pb-1">
                <div class="cat-item d-flex flex-column border mb-4" style="padding: 30px;">
                    <p class="text-right">15 Products</p>
                    <a href="shop.html" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="img/GYM BAG.webp" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">BAGS</h5>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 pb-1">
                <div class="cat-item d-flex flex-column border mb-4" style="padding: 30px;">
                    <p class="text-right">15</p>
                    <a href="shop.html" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="img/creatine_monohydrate-01.webp" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">CREATINE</h5>
                </div>
            </div>
        </div>
    </div>
    <!-- Categories End -->


    <!-- Offer Start -->
    <div class="container-fluid offer pt-5">
        <div class="row px-xl-5">
            <div class="col-md-6 pb-4">
                <div class="position-relative bg-secondary text-center text-md-right text-white mb-2 py-5 px-5">
                    <img src="img/39aa61150182487.62f5ffd6bc924.jpg" alt="">
                    <div class="position-relative" style="z-index: 1;">
                        <h5 class="text-uppercase text-primary mb-3">20% off the all order</h5>
                        <h1 class="mb-4 font-weight-semi-bold">Spring Offer </h1>
                        <a href="shop.html" class="btn btn-outline-primary py-md-2 px-md-3">Shop Now</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 pb-4">
                <div class="position-relative bg-secondary text-center text-md-left text-white mb-2 py-5 px-5">
                    <img src="img/fad760150182487.62f50afa2c3a4.jpg" alt="">
                    <div class="position-relative" style="z-index: 1;">
                        <h5 class="text-uppercase text-primary mb-3">20% off the all order</h5>
                        <h1 class="mb-4 font-weight-semi-bold">Winter Offer</h1>
                        <a href="shop.html" class="btn btn-outline-primary py-md-2 px-md-3">Shop Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Offer End -->


    <!-- Products Start -->
    <div class="container-fluid pt-5">
        <div class="text-center mb-4">
            <h2 class="section-title px-5"><span class="px-2">Trendy Products</span></h2>
        </div>
        <div class="row px-xl-5 pb-3">
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="card product-item border-0 mb-4">
                    <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                        <img class="img-fluid w-100" src="img/PSYCHOTIC.webp" alt="">
                    </div>
                    <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                        <h6 class="text-truncate mb-3">PREWORKOUT</h6>
                        <div class="d-flex justify-content-center">
                            <h6>INR 623.00</h6>
                            <h6 class="text-muted ml-2"><del>INR 723.00</del></h6>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-between bg-light border">
                        <a href="detail.html" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary mr-1"></i>View Detail</a>
                        <a href="cart.html" class="btn btn-sm text-dark p-0"><i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="card product-item border-0 mb-4">
                    <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                        <img class="img-fluid w-100" src="img/creatine_monohydrate-01.webp" alt="">
                    </div>
                    <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                        <h6 class="text-truncate mb-3"> CREATINE</h6>
                        <div class="d-flex justify-content-center">
                            <h6>INR 923.00</h6>
                            <h6 class="text-muted ml-2"><del>$25.00</del></h6>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-between bg-light border">
                        <a href="detail.html" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary mr-1"></i>View Detail</a>
                        <a href="cart.html" class="btn btn-sm text-dark p-0"><i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="card product-item border-0 mb-4">
                    <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                        <img class="img-fluid w-100" src="img/MULTIVITAMIN.webp" alt="">
                    </div>
                    <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                        <h6 class="text-truncate mb-3"> MULTIVITAMIN</h6>
                        <div class="d-flex justify-content-center">
                            <h6>INR 330.00</h6>
                            <h6 class="text-muted ml-2"><del>INR 433.00</del></h6>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-between bg-light border">
                        <a href="detail.html" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary mr-1"></i>View Detail</a>
                        <a href="cart.html" class="btn btn-sm text-dark p-0"><i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="card product-item border-0 mb-4">
                    <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                        <img class="img-fluid w-100" src="img/Labrada-mass-6.6lb.jpg" alt="">
                    </div>
                    <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                        <h6 class="text-truncate mb-3"> MASSGAINER</h6>
                        <div class="d-flex justify-content-center">
                            <h6>INR 3499.00</h6>
                            <h6 class="text-muted ml-2"><del>INR3999.00</del></h6>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-between bg-light border">
                        <a href="detail.html" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary mr-1"></i>View Detail</a>
                        <a href="cart.html" class="btn btn-sm text-dark p-0"><i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="card product-item border-0 mb-4">
                    <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                        <img class="img-fluid w-100" src="img/shaker.webp" alt="">
                    </div>
                    <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                        <h6 class="text-truncate mb-3">SHAKERS</h6>
                        <div class="d-flex justify-content-center">
                            <h6>INR 120.00</h6>
                            <h6 class="text-muted ml-2"><del>INR 200.00</del></h6>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-between bg-light border">
                        <a href="detail.html" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary mr-1"></i>View Detail</a>
                        <a href="cart.html" class="btn btn-sm text-dark p-0"><i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="card product-item border-0 mb-4">
                    <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                        <img class="img-fluid w-100" src="img/ONWHEY.webp"  alt="">
                    </div>
                    <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                        <h6 class="text-truncate mb-3"> ADVANCED WHEY PROTEIN</h6>
                        <div class="d-flex justify-content-center">
                            <h6>INR 2200.00</h6>
                            <h6 class="text-muted ml-2"><del>INR 2325.00</del></h6>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-between bg-light border">
                        <a href="detail.html" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary mr-1"></i>View Detail</a>
                        <a href="cart.html" class="btn btn-sm text-dark p-0"><i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="card product-item border-0 mb-4">
                    <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                        <img class="img-fluid w-100" src="img/FISHOIL.webp" alt="">
                    </div>
                    <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                        <h6 class="text-truncate mb-3"> FISHOIL</h6>
                        <div class="d-flex justify-content-center">
                            <h6>INR 440.00</h6>
                            <h6 class="text-muted ml-2"><del>INR 550.00</del></h6>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-between bg-light border">
                        <a href="detail.html" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary mr-1"></i>View Detail</a>
                        <a href="cart.html" class="btn btn-sm text-dark p-0"><i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="card product-item border-0 mb-4">
                    <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                        <img class="img-fluid w-100" src="img/NB-ASI-1006-04-01-510x510.webp" alt="">
                    </div>
                    <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                        <h6 class="text-truncate mb-3">PROTEIN</h6>
                        <div class="d-flex justify-content-center">
                            <h6>INR 3100.00</h6>
                            <h6 class="text-muted ml-2"><del>INR 3399.00</del></h6>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-between bg-light border">
                        <a href="detail.html" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary mr-1"></i>View Detail</a>
                        <a href="cart.html" class="btn btn-sm text-dark p-0"><i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Products End -->


    <!-- Subscribe Start -->
    <div class="container-fluid bg-secondary my-5">
        <div class="row justify-content-md-center py-5 px-xl-5">
            <div class="col-md-6 col-12 py-5">
                <div class="text-center mb-2 pb-2">
                    <h2 class="section-title px-5 mb-3"><span class="bg-secondary px-2">Stay Updated</span></h2>
                    <p>Level up your fitness journey with Fitness Essentials </p>
                </div>
                <form action="">
                    <div class="input-group">
                        <input type="text" class="form-control border-white p-4" placeholder="Email Goes Here">
                        <div class="input-group-append">
                            <button class="btn btn-primary px-4">Subscribe</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Subscribe End -->


    <!-- Products Start -->
    <div class="container-fluid pt-5">
        <div class="text-center mb-4">
            <h2 class="section-title px-5"><span class="px-2">Just Arrived</span></h2>
        </div>
        <div class="row px-xl-5 pb-3">
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="card product-item border-0 mb-4">
                    <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                        <img class="img-fluid w-100" src="img/ GLOVES.jpeg" alt="">
                    </div>
                    <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                        <h6 class="text-truncate mb-3">GLOVES </h6>
                        <div class="d-flex justify-content-center">
                            <h6>INR 623.00</h6>
                            <h6 class="text-muted ml-2"><del>INR 723.00</del></h6>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-between bg-light border">
                        <a href="detail.html" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary mr-1"></i>View Detail</a>
                        <a href="cart.html" class="btn btn-sm text-dark p-0"><i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="card product-item border-0 mb-4">
                    <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                        <img class="img-fluid w-100" src="img/BCAA.webp" alt="">
                    </div>
                    <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                        <h6 class="text-truncate mb-3">BCAA ADVANCED </h6>
                        <div class="d-flex justify-content-center">
                            <h6>INR 899.00</h6>
                            <h6 class="text-muted ml-2"><del>INR 999.00</del></h6>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-between bg-light border">
                        <a href="detail.html" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary mr-1"></i>View Detail</a>
                        <a href="cart.html" class="btn btn-sm text-dark p-0"><i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="card product-item border-0 mb-4">
                    <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                        <img class="img-fluid w-100" src="img/ bar.webp" alt="">
                    </div>
                    <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                        <h6 class="text-truncate mb-3">PROTEIN BAR</h6>
                        <div class="d-flex justify-content-center">
                            <h6> INR 323.00</h6>
                            <h6 class="text-muted ml-2"><del>INR 400.00</del></h6>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-between bg-light border">
                        <a href="detail.html" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary mr-1"></i>View Detail</a>
                        <a href="cart.html" class="btn btn-sm text-dark p-0"><i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="card product-item border-0 mb-4">
                    <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                        <img class="img-fluid w-100" src="img/BIGMUSCLESMASS.webp" alt="">
                    </div>
                    <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                        <h6 class="text-truncate mb-3">Colorful Stylish Shirt</h6>
                        <div class="d-flex justify-content-center">
                            <h6>$123.00</h6>
                            <h6 class="text-muted ml-2"><del>$123.00</del></h6>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-between bg-light border">
                        <a href="detail.html" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary mr-1"></i>View Detail</a>
                        <a href="cart.html" class="btn btn-sm text-dark p-0"><i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="card product-item border-0 mb-4">
                    <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                        <img class="img-fluid w-100" src="img/butter.webp" alt="">
                    </div>
                    <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                        <h6 class="text-truncate mb-3">PEANUT BUTTER </h6>
                        <div class="d-flex justify-content-center">
                            <h6>INR 499.00</h6>
                            <h6 class="text-muted ml-2"><del>INR 599.00</del></h6>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-between bg-light border">
                        <a href="detail.html" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary mr-1"></i>View Detail</a>
                        <a href="cart.html" class="btn btn-sm text-dark p-0"><i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="card product-item border-0 mb-4">
                    <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                        <img class="img-fluid w-100" src="img/BCAA 2 .webp" alt="">
                    </div>
                    <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                        <h6 class="text-truncate mb-3">BCAA</h6>
                        <div class="d-flex justify-content-center">
                            <h6>INR 800.00</h6>
                            <h6 class="text-muted ml-2"><del>INR 900.00</del></h6>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-between bg-light border">
                        <a href="detail.html" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary mr-1"></i>View Detail</a>
                        <a href="cart.html" class="btn btn-sm text-dark p-0"><i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="card product-item border-0 mb-4">
                    <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                        <img class="img-fluid w-100" src="img/GLUT.webp" alt="">
                    </div>
                    <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                        <h6 class="text-truncate mb-3">GLUTAMINE </h6>
                        <div class="d-flex justify-content-center">
                            <h6>INR 423.00</h6>
                            <h6 class="text-muted ml-2"><del>INR 523.00</del></h6>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-between bg-light border">
                        <a href="detail.html" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary mr-1"></i>View Detail</a>
                        <a href="cart.html" class="btn btn-sm text-dark p-0"><i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="card product-item border-0 mb-4">
                    <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                        <img class="img-fluid w-100" src="img/BIOTIN.webp" alt="">
                    </div>
                    <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                        <h6 class="text-truncate mb-3"> BIOTIN</h6>
                        <div class="d-flex justify-content-center">
                            <h6>INR 623.00</h6>
                            <h6 class="text-muted ml-2"><del>INR 723.00</del></h6>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-between bg-light border">
                        <a href="detail.html" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary mr-1"></i>View Detail</a>
                        <a href="cart.html" class="btn btn-sm text-dark p-0"><i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Products End -->


    <!-- Vendor Start -->
    <div class="container-fluid py-5">
        <div class="row px-xl-5">
            <div class="col">
                <div class="owl-carousel vendor-carousel">
                    <div class="vendor-item border p-4">
                        <img src="img/vendor-1.jpg" alt="">
                    </div>
                    <div class="vendor-item border p-4">
                        <img src="img/vendor-2.jpg" alt="">
                    </div>
                    <div class="vendor-item border p-4">
                        <img src="img/vendor-3.jpg" alt="">
                    </div>
                    <div class="vendor-item border p-4">
                        <img src="img/vendor-4.jpg" alt="">
                    </div>
                    <div class="vendor-item border p-4">
                        <img src="img/vendor-5.jpg" alt="">
                    </div>
                    <div class="vendor-item border p-4">
                        <img src="img/vendor-6.jpg" alt="">
                    </div>
                    <div class="vendor-item border p-4">
                        <img src="img/vendor-7.jpg" alt="">
                    </div>
                    <div class="vendor-item border p-4">
                        <img src="img/vendor-8.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Vendor End -->


    <!-- Footer Start -->
    <div class="container-fluid bg-secondary text-dark mt-5 pt-5">
        <div class="row px-xl-5 pt-5">
            <div class="col-lg-4 col-md-12 mb-5 pr-3 pr-xl-5">
                <a href="" class="text-decoration-none">
                    <h1 class="mb-4 display-5 font-weight-semi-bold"><span class="text-primary font-weight-bold border border-white px-3 mr-1">GYM</span>ESSENTIALS</h1>
                </a>
                <p> Just fill out the form below and we'll get back to you as soon as possible.</p>
                <p class="mb-2"><i class="fa fa-map-marker-alt text-primary mr-3"></i>1/13 Fanaswadi Mumbai 400002 </p>
                <p class="mb-2"><i class="fa fa-envelope text-primary mr-3"></i>VisheshSanghvi112@gmail.com</p>
                <p class="mb-0"><i class="fa fa-phone-alt text-primary mr-3"></i>+917977292697</p>
            </div>
            <div class="col-lg-8 col-md-12">
                <div class="row">
                    <div class="col-md-4 mb-5">
                        <h5 class="font-weight-bold text-dark mb-4">Quick Links</h5>
                        <div class="d-flex flex-column justify-content-start">
                            <a class="text-dark mb-2" href="index.html"><i class="fa fa-angle-right mr-2"></i>Home</a>
                            <a class="text-dark mb-2" href="shop.html"><i class="fa fa-angle-right mr-2"></i>Our Shop</a>
                            <a class="text-dark mb-2" href="detail.html"><i class="fa fa-angle-right mr-2"></i>Shop Detail</a>
                            <a class="text-dark mb-2" href="cart.html"><i class="fa fa-angle-right mr-2"></i>Shopping Cart</a>
                            <a class="text-dark mb-2" href="checkout.html"><i class="fa fa-angle-right mr-2"></i>Checkout</a>
                            <a class="text-dark" href="contact.html"><i class="fa fa-angle-right mr-2"></i>Contact Us</a>
                        </div>
                    </div>
                    <div class="col-md-4 mb-5">
                        <h5 class="font-weight-bold text-dark mb-4">Quick Links</h5>
                        <div class="d-flex flex-column justify-content-start">
                            <a class="text-dark mb-2" href="index.html"><i class="fa fa-angle-right mr-2"></i>Home</a>
                            <a class="text-dark mb-2" href="shop.html"><i class="fa fa-angle-right mr-2"></i>Our Shop</a>
                            <a class="text-dark mb-2" href="detail.html"><i class="fa fa-angle-right mr-2"></i>Shop Detail</a>
                            <a class="text-dark mb-2" href="cart.html"><i class="fa fa-angle-right mr-2"></i>Shopping Cart</a>
                            <a class="text-dark mb-2" href="checkout.html"><i class="fa fa-angle-right mr-2"></i>Checkout</a>
                            <a class="text-dark" href="contact.html"><i class="fa fa-angle-right mr-2"></i>Contact Us</a>
                        </div>
                    </div>
                    <div class="col-md-4 mb-5">
                        <h5 class="font-weight-bold text-dark mb-4">Newsletter</h5>
                        <form action="">
                            <div class="form-group">
                                <input type="text" class="form-control border-0 py-4" placeholder="Your Name" required="required" />
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control border-0 py-4" placeholder="Your Email" required="required" />
                            </div>
                            <div>
                                <button class="btn btn-primary btn-block border-0 py-3" type="submit">Subscribe Now</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row border-top border-light mx-xl-5 py-4">
            <div class="col-md-6 px-xl-0">
                <p class="mb-md-0 text-center text-md-left text-dark">
                    &copy; <a class="text-dark font-weight-semi-bold" href="FitnessEssentials.vishesh">FitnessEssentials</a>. All Rights Reserved. Designed by
                    <a class="text-dark font-weight-semi-bold" href="https://htmlcodex.com">VISHESH SANGHVI</a>
                    <div class="spr-container">
                        <div class="spr-header">
                            <h2 class="spr-header-title">Customer Reviews</h2>
                            <div class="spr-summary rte"> <span class="spr-starrating spr-summary-starrating" aria-label="5.0 of 5 stars" role="img"> <i class="spr-icon spr-icon-star" aria-hidden="true"></i><i class="spr-icon spr-icon-star" aria-hidden="true"></i><i class="spr-icon spr-icon-star" aria-hidden="true"></i><i class="spr-icon spr-icon-star" aria-hidden="true"></i><i class="spr-icon spr-icon-star" aria-hidden="true"></i></span>                                <span class="spr-summary-caption"><span class='spr-summary-actions-togglereviews'>Based on 1 review</span></span><span class="spr-summary-actions"> <a href='#' class='spr-summary-actions-newreview' onclick='SPR.toggleForm(7474433949939);return false'>Write a review</a></span></div>
                        </div>
                        <div class="spr-content">
                            <div class='spr-form' id='form_7474433949939' style='display: none'></div>
                            <div class='spr-reviews' id='reviews_7474433949939'></div>
                        </div>

                </p>
                </div>
                <div class="col-md-6 px-xl-0 text-center text-md-right">
                    <img class="img-fluid" src="img/payments.png" alt="">
                </div>
            </div>
        </div>
        <!-- Footer End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


        

        <!-- JavaScript Libraries -->
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
        <script src="lib/easing/easing.min.js"></script>
        <script src="lib/owlcarousel/owl.carousel.min.js"></script>

        <!-- Contact Javascript File -->
        <script src="mail/jqBootstrapValidation.min.js"></script>
        <script src="mail/contact.js"></script>

        <!-- Template Javascript -->
        <script src="js/main.js"></script>
</body>

</html>